/**
 * AnimeVerse Utilities
 */

function toast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const el = document.createElement('div');
  el.className = 'toast';
  const icons = {
    info: '<svg class="w-4 h-4 text-aurora-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>',
    success: '<svg class="w-4 h-4 text-emerald-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>',
    error: '<svg class="w-4 h-4 text-red-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>',
  };
  el.innerHTML = `${icons[type] || icons.info}<span>${message}</span>`;
  container.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 400);
  }, 3200);
}

function debounce(fn, ms = 280) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

function createPosterEl(item, className = '') {
  const div = document.createElement('div');
  div.className = `w-full h-full bg-gradient-to-br ${item.posterGradient || 'from-void-700 to-void-900'} ${className}`;
  div.setAttribute('aria-hidden', 'true');
  // Subtle pattern overlay
  div.innerHTML = `<div class="absolute inset-0 opacity-20" style="background-image: radial-gradient(circle at 30% 40%, rgba(255,255,255,0.15) 0%, transparent 50%);"></div>`;
  return div;
}

function formatRuntime(mins) {
  if (!mins) return '';
  if (mins < 60) return `${mins}m`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m ? `${h}h ${m}m` : `${h}h`;
}

function getById(id) {
  return CATALOG.find(a => a.id === id);
}

// Local storage helpers (demo persistence)
const storage = {
  get(key, fallback = null) {
    try {
      const v = localStorage.getItem(`av_${key}`);
      return v ? JSON.parse(v) : fallback;
    } catch { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem(`av_${key}`, JSON.stringify(value)); } catch {}
  },
};

function addToWatchlist(id) {
  const list = storage.get('watchlist', []);
  if (!list.includes(id)) {
    list.push(id);
    storage.set('watchlist', list);
    toast('Added to Watchlist', 'success');
  } else {
    toast('Already in Watchlist', 'info');
  }
}

function toggleFavorite(id) {
  const favs = storage.get('favorites', []);
  const idx = favs.indexOf(id);
  if (idx === -1) {
    favs.push(id);
    storage.set('favorites', favs);
    toast('Added to Favorites', 'success');
    return true;
  } else {
    favs.splice(idx, 1);
    storage.set('favorites', favs);
    toast('Removed from Favorites', 'info');
    return false;
  }
}

// Generic scroll-reveal: activates any element with class "reveal-on-scroll"
function initScrollReveal() {
  const els = document.querySelectorAll('.reveal-on-scroll');
  if (!els.length) return;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    els.forEach(el => el.classList.add('is-visible'));
    return;
  }
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  els.forEach(el => io.observe(el));
}
document.addEventListener('DOMContentLoaded', initScrollReveal);
