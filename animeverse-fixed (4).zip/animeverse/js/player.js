/**
 * Cinematic video player (demo UI only)
 * Connects to authorized media sources in production.
 * Includes Cinema Mode: hide chrome, expand, dim surroundings.
 */

function initPlayer() {
  const overlay = document.getElementById('player-overlay');
  const container = document.getElementById('player-container');
  const controls = document.getElementById('player-controls');
  let hideTimer;
  let cinemaMode = false;
  let currentItem = null;
  let playing = false;

  function showControls() {
    if (cinemaMode && playing) {
      controls?.classList.add('show');
      clearTimeout(hideTimer);
      hideTimer = setTimeout(() => {
        if (cinemaMode) controls?.classList.remove('show');
      }, 2500);
    } else {
      controls?.classList.add('show');
      clearTimeout(hideTimer);
      hideTimer = setTimeout(() => controls?.classList.remove('show'), 3500);
    }
  }

  container?.addEventListener('mousemove', showControls);
  container?.addEventListener('click', showControls);

  document.getElementById('player-close')?.addEventListener('click', closePlayer);
  document.getElementById('player-play-big')?.addEventListener('click', () => {
    playing = true;
    toast('Playback started (demo)', 'info');
    showControls();
    updatePlayIcon(true);
    setTimeout(() => {
      const skip = document.getElementById('skip-intro');
      if (skip && playing) {
        skip.classList.remove('opacity-0', 'pointer-events-none');
        skip.classList.add('opacity-100');
      }
    }, 2000);
  });
  document.getElementById('player-play')?.addEventListener('click', () => {
    playing = !playing;
    updatePlayIcon(playing);
    toast(playing ? 'Playing' : 'Paused', 'info');
  });

  document.getElementById('skip-intro')?.addEventListener('click', () => {
    const skip = document.getElementById('skip-intro');
    skip?.classList.add('opacity-0', 'pointer-events-none');
    skip?.classList.remove('opacity-100');
    const fill = document.getElementById('player-progress-bar');
    if (fill) fill.style.width = '12%';
    toast('Intro skipped', 'info');
  });

  let nextTimer = null;
  function showNextEpisode() {
    if (!currentItem || currentItem.type !== 'series') return;
    const screen = document.getElementById('next-episode-screen');
    const titleEl = document.getElementById('next-ep-title');
    const countEl = document.getElementById('next-countdown');
    if (titleEl) titleEl.textContent = `${currentItem.title} — Next Episode`;
    let count = 8;
    if (countEl) countEl.textContent = String(count);
    screen?.classList.remove('opacity-0', 'pointer-events-none');
    screen?.classList.add('opacity-100');
    clearInterval(nextTimer);
    nextTimer = setInterval(() => {
      count--;
      if (countEl) countEl.textContent = String(count);
      if (count <= 0) {
        clearInterval(nextTimer);
        hideNextEpisode();
        toast('Playing next episode (demo)', 'info');
        playing = true;
        updatePlayIcon(true);
      }
    }, 1000);
  }
  function hideNextEpisode() {
    clearInterval(nextTimer);
    const screen = document.getElementById('next-episode-screen');
    screen?.classList.add('opacity-0', 'pointer-events-none');
    screen?.classList.remove('opacity-100');
  }
  document.getElementById('next-cancel')?.addEventListener('click', hideNextEpisode);
  document.getElementById('next-play')?.addEventListener('click', () => {
    hideNextEpisode();
    toast('Playing next episode (demo)', 'info');
    playing = true;
    updatePlayIcon(true);
  });

  function updatePlayIcon(isPlaying) {
    const btn = document.getElementById('player-play');
    if (!btn) return;
    btn.innerHTML = isPlaying
      ? '<svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z"/></svg>'
      : '<svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>';
  }

  // Cinema Mode — immersive theater
  document.getElementById('player-theater')?.addEventListener('click', toggleCinema);

  function toggleCinema() {
    cinemaMode = !cinemaMode;
    if (cinemaMode) {
      container?.classList.remove('max-w-6xl', 'sm:rounded-xl');
      container?.classList.add('w-full', 'h-full', 'max-w-none', 'rounded-none');
      overlay?.classList.add('cinema-active');
      // Dim letterbox feel
      if (overlay) {
        overlay.style.background = 'radial-gradient(ellipse at center, #0a0a0f 0%, #000 70%)';
      }
      toast('Cinema Mode on — minimal controls', 'info');
      showControls();
    } else {
      container?.classList.add('max-w-6xl', 'sm:rounded-xl');
      container?.classList.remove('w-full', 'h-full', 'max-w-none', 'rounded-none');
      overlay?.classList.remove('cinema-active');
      if (overlay) overlay.style.background = '';
      toast('Cinema Mode off', 'info');
    }
  }

  document.getElementById('player-fs')?.addEventListener('click', () => {
    if (!document.fullscreenElement) {
      (overlay || container)?.requestFullscreen?.();
    } else {
      document.exitFullscreen?.();
    }
  });

  document.getElementById('player-speed')?.addEventListener('click', (e) => {
    const speeds = ['0.75x', '1x', '1.25x', '1.5x', '2x'];
    const cur = e.target.textContent;
    e.target.textContent = speeds[(speeds.indexOf(cur) + 1) % speeds.length];
  });

  document.getElementById('player-quality')?.addEventListener('click', (e) => {
    const qs = ['720p', '1080p', '4K'];
    const cur = e.target.textContent;
    e.target.textContent = qs[(qs.indexOf(cur) + 1) % qs.length];
  });

  document.getElementById('player-subs')?.addEventListener('click', () => {
    toast('Subtitles: Off → English → Japanese (demo)', 'info');
  });

  // Progress click (demo seek) — near end triggers next-episode screen
  document.getElementById('player-progress')?.addEventListener('click', (e) => {
    const bar = e.currentTarget;
    const rect = bar.getBoundingClientRect();
    const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const fill = document.getElementById('player-progress-bar');
    if (fill) fill.style.width = (pct * 100) + '%';
    const total = 24 * 60;
    const cur = Math.floor(pct * total);
    const t = document.getElementById('player-time');
    if (t) t.textContent = `${String(Math.floor(cur / 60)).padStart(2, '0')}:${String(cur % 60).padStart(2, '0')} / 24:00`;
    if (pct > 0.9 && currentItem?.type === 'series') {
      setTimeout(showNextEpisode, 500);
    }
  });

  // Keyboard
  document.addEventListener('keydown', (e) => {
    if (overlay?.classList.contains('opacity-0')) return;
    if (e.key === 'Escape') {
      if (cinemaMode) toggleCinema();
      else closePlayer();
    }
    if (e.key === ' ') {
      e.preventDefault();
      playing = !playing;
      updatePlayIcon(playing);
    }
    if (e.key === 't' || e.key === 'T') toggleCinema();
    if (e.key === 'f' || e.key === 'F') {
      if (!document.fullscreenElement) (overlay || container)?.requestFullscreen?.();
      else document.exitFullscreen?.();
    }
  });

  document.getElementById('player-episode')?.addEventListener('change', (e) => {
    toast(`Episode ${e.target.value} (demo)`, 'info');
    const fill = document.getElementById('player-progress-bar');
    if (fill) fill.style.width = '0%';
    playing = true;
    updatePlayIcon(true);
  });

  window.openPlayer = function (item) {
    if (!item) return;
    currentItem = item;
    playing = false;
    cinemaMode = false;
    hideNextEpisode();
    document.getElementById('skip-intro')?.classList.add('opacity-0', 'pointer-events-none');
    const epSelect = document.getElementById('player-episode');
    if (epSelect) {
      const n = item.type === 'series' ? Math.min(item.episodes || 12, 24) : 1;
      epSelect.innerHTML = Array.from({ length: n }, (_, i) =>
        `<option value="${i + 1}">Ep ${i + 1}</option>`
      ).join('');
      epSelect.classList.toggle('hidden', item.type !== 'series');
      if (item.type === 'series') epSelect.classList.remove('sm:hidden');
    }
    container?.classList.add('max-w-6xl', 'sm:rounded-xl');
    container?.classList.remove('w-full', 'h-full', 'max-w-none', 'rounded-none');
    if (overlay) overlay.style.background = '';
    overlay.classList.remove('opacity-0', 'pointer-events-none');
    overlay.classList.add('opacity-100');
    document.body.style.overflow = 'hidden';
    updatePlayIcon(false);
    showControls();
    toast(`Playing: ${item.title} (demo — authorized sources only)`, 'info');
  };

  function closePlayer() {
    cinemaMode = false;
    playing = false;
    currentItem = null;
    hideNextEpisode();
    document.getElementById('skip-intro')?.classList.add('opacity-0', 'pointer-events-none');
    overlay.classList.add('opacity-0', 'pointer-events-none');
    overlay.classList.remove('opacity-100', 'cinema-active');
    if (overlay) overlay.style.background = '';
    container?.classList.add('max-w-6xl');
    document.body.style.overflow = '';
  }
}
