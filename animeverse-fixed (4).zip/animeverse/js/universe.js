/**
 * Interactive 3D Anime Universe (Three.js)
 * Falls back gracefully on low-power devices.
 */

function initUniverse() {
  const canvas = document.getElementById('universe-canvas');
  const container = canvas?.parentElement;
  const fallback = document.getElementById('universe-fallback');
  const infoPanel = document.getElementById('universe-info');
  if (!canvas || typeof THREE === 'undefined') {
    fallback?.classList.remove('hidden');
    return;
  }

  // Detect weak devices
  const isWeak = navigator.hardwareConcurrency <= 4 || /Android|iPhone|iPad/i.test(navigator.userAgent);
  if (isWeak && window.innerWidth < 768) {
    fallback?.classList.remove('hidden');
    document.getElementById('universe-2d-btn')?.addEventListener('click', () => {
      fallback.classList.add('hidden');
      // Simple 2D grid fallback already partially visible via cards
      toast('2D explorer active', 'info');
    });
  }

  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x0a0a0f, 0.015);

  const camera = new THREE.PerspectiveCamera(55, 1, 0.1, 200);
  camera.position.set(0, 8, 28);

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: !isWeak, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, isWeak ? 1 : 2));
  renderer.setClearColor(0x0a0a0f, 0);

  // Lights
  const ambient = new THREE.AmbientLight(0x404060, 0.6);
  scene.add(ambient);
  const point1 = new THREE.PointLight(0x6e7cf6, 1.2, 80);
  point1.position.set(15, 20, 10);
  scene.add(point1);
  const point2 = new THREE.PointLight(0x5b66c9, 0.8, 60);
  point2.position.set(-12, 10, -8);
  scene.add(point2);

  // Nodes from catalog
  const nodes = [];
  const group = new THREE.Group();
  scene.add(group);

  const colors = {
    series: 0x6e7cf6,
    movie: 0x5b66c9,
    studio: 0xf0a85c,
  };

  CATALOG.forEach((item, i) => {
    const angle = (i / CATALOG.length) * Math.PI * 2;
    const radius = 8 + (i % 3) * 3;
    const y = (Math.random() - 0.5) * 10;
    const geo = new THREE.SphereGeometry(item.type === 'movie' ? 0.35 : 0.5, isWeak ? 8 : 16, isWeak ? 8 : 16);
    const mat = new THREE.MeshStandardMaterial({
      color: colors[item.type] || 0x6e7cf6,
      emissive: colors[item.type] || 0x6e7cf6,
      emissiveIntensity: 0.35,
      metalness: 0.3,
      roughness: 0.5,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(Math.cos(angle) * radius, y, Math.sin(angle) * radius);
    mesh.userData = { item };
    group.add(mesh);
    nodes.push(mesh);

    // Soft glow sprite-like ring
    if (!isWeak) {
      const ringGeo = new THREE.RingGeometry(0.6, 0.75, 16);
      const ringMat = new THREE.MeshBasicMaterial({ color: colors[item.type], transparent: true, opacity: 0.15, side: THREE.DoubleSide });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = -Math.PI / 2;
      mesh.add(ring);
    }
  });

  // Connection lines (sample)
  const lineMat = new THREE.LineBasicMaterial({ color: 0x4c1d95, transparent: true, opacity: 0.25 });
  for (let i = 0; i < nodes.length - 1; i += 2) {
    const points = [nodes[i].position.clone(), nodes[(i + 3) % nodes.length].position.clone()];
    const geo = new THREE.BufferGeometry().setFromPoints(points);
    group.add(new THREE.Line(geo, lineMat));
  }

  // Particles
  const particleCount = isWeak ? 100 : 300;
  const pGeo = new THREE.BufferGeometry();
  const positions = new Float32Array(particleCount * 3);
  for (let i = 0; i < particleCount * 3; i++) {
    positions[i] = (Math.random() - 0.5) * 60;
  }
  pGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const pMat = new THREE.PointsMaterial({ color: 0x8f9af8, size: 0.08, transparent: true, opacity: 0.6 });
  scene.add(new THREE.Points(pGeo, pMat));

  // Resize
  function resize() {
    const w = container.clientWidth;
    const h = container.clientHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h, false);
  }
  resize();
  window.addEventListener('resize', resize);

  // Interaction
  let isDragging = false;
  let prevX = 0, prevY = 0;
  let targetRotY = 0, targetRotX = 0.15;
  let currentRotY = 0, currentRotX = 0.15;
  let zoom = 28;

  canvas.addEventListener('pointerdown', (e) => {
    isDragging = true;
    prevX = e.clientX;
    prevY = e.clientY;
    canvas.setPointerCapture(e.pointerId);
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!isDragging) return;
    const dx = e.clientX - prevX;
    const dy = e.clientY - prevY;
    targetRotY += dx * 0.005;
    targetRotX += dy * 0.004;
    targetRotX = Math.max(-0.6, Math.min(0.8, targetRotX));
    prevX = e.clientX;
    prevY = e.clientY;
  });
  canvas.addEventListener('pointerup', () => { isDragging = false; });
  canvas.addEventListener('pointerleave', () => { isDragging = false; });

  canvas.addEventListener('wheel', (e) => {
    e.preventDefault();
    zoom += e.deltaY * 0.02;
    zoom = Math.max(12, Math.min(45, zoom));
  }, { passive: false });

  // Raycaster for click
  const raycaster = new THREE.Raycaster();
  const mouse = new THREE.Vector2();
  canvas.addEventListener('click', (e) => {
    if (isDragging) return;
    const rect = canvas.getBoundingClientRect();
    mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);
    const hits = raycaster.intersectObjects(nodes);
    if (hits.length) {
      const item = hits[0].object.userData.item;
      showUniverseInfo(item);
    }
  });

  function showUniverseInfo(item) {
    if (!infoPanel) return;
    document.getElementById('universe-info-title').textContent = item.title;
    document.getElementById('universe-info-meta').textContent = `${item.type} · ${item.year} · ${item.studio}`;
    document.getElementById('universe-info-desc').textContent = item.description;
    const poster = document.getElementById('universe-info-poster');
    poster.className = `w-20 h-28 rounded-lg flex-shrink-0 bg-gradient-to-br ${item.posterGradient}`;
    infoPanel.classList.remove('opacity-0', 'pointer-events-none');
    infoPanel.classList.add('opacity-100');
    document.getElementById('universe-info-btn').onclick = () => window.openDetail?.(item.id);
  }

  // Filters
  document.querySelectorAll('.universe-ctrl').forEach(btn => {
    btn.addEventListener('click', () => {
      const filter = btn.dataset.filter;
      nodes.forEach(n => {
        const t = n.userData.item.type;
        if (filter === 'all') n.visible = true;
        else if (filter === 'anime') n.visible = t === 'series';
        else if (filter === 'movies') n.visible = t === 'movie';
        else n.visible = true;
      });
    });
  });

  // Animate
  const clock = new THREE.Clock();
  function animate() {
    requestAnimationFrame(animate);
    const t = clock.getElapsedTime();
    currentRotY += (targetRotY - currentRotY) * 0.08;
    currentRotX += (targetRotX - currentRotX) * 0.08;
    group.rotation.y = currentRotY + t * 0.02;
    group.rotation.x = currentRotX;
    camera.position.z += (zoom - camera.position.z) * 0.08;
    camera.lookAt(0, 0, 0);
    // gentle node pulse
    nodes.forEach((n, i) => {
      n.scale.setScalar(1 + Math.sin(t * 1.5 + i) * 0.04);
    });
    renderer.render(scene, camera);
  }
  animate();
}
