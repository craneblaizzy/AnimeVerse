/**
 * AnimeVerse — Mobile App Shell (app.html)
 * Depends on: data/mock.js (CATALOG, GENRES, NOTIFICATIONS) and js/utils.js
 * (toast, debounce, storage, addToWatchlist). No backend: swap the data
 * source in `getCatalog()` when a real API is available.
 */
(function () {
  'use strict';

  /* ------------------------------------------------------------------
     Data access (single seam for a future API layer)
  ------------------------------------------------------------------ */
  const getCatalog = () => CATALOG;
  const getGenres = () => GENRES;
  const getNotifications = () => NOTIFICATIONS;
  const findTitle = (id) => getCatalog().find((c) => c.id === id);

  const $ = (id) => document.getElementById(id);
  const escapeHtml = (s) =>
    String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* ------------------------------------------------------------------
     Derived homepage sets (real catalog data only)
  ------------------------------------------------------------------ */
  const catalog = getCatalog();
  const maxYear = Math.max(...catalog.map((c) => c.year));
  const byRating = [...catalog].sort((a, b) => b.rating - a.rating);

  const rowDefs = [
    { title: 'Continue Watching', items: catalog.filter((c) => c.progress > 0 && c.progress < 1), progress: true },
    { title: 'Trending Now', items: byRating.slice(0, 8) },
    { title: 'New Releases', items: catalog.filter((c) => c.year === maxYear) },
    { title: 'Currently Airing', items: catalog.filter((c) => c.status === 'Airing') },
    { title: 'Hidden Gems', items: [...catalog].sort((a, b) => a.rating - b.rating).slice(0, 6) },
  ].filter((r) => r.items.length);

  const badgeFor = (it) => (it.status === 'Airing' ? 'AIRING' : it.year === maxYear ? 'NEW' : '');

  function posterBg(it) {
    return `<div class="absolute inset-0 bg-gradient-to-br ${escapeHtml(it.posterGradient)}" aria-hidden="true">
      <div class="absolute inset-0 opacity-25" style="background-image:radial-gradient(circle at 40% 30%,rgba(255,255,255,.25) 0%,transparent 55%)"></div></div>`;
  }

  /* ------------------------------------------------------------------
     Overlay state (scroll lock + Escape handling)
  ------------------------------------------------------------------ */
  const sheet = $('sheet'), backdrop = $('sheetBackdrop');
  const searchOverlay = $('searchOverlay'), searchInput = $('searchInput'), searchResults = $('searchResults');
  const notifDrawer = $('notifDrawer'), notifList = $('notifList');
  let lastTrigger = null;

  const isOpen = (el) => el.classList.contains('open');
  const syncScrollLock = () => {
    document.body.style.overflow = isOpen(sheet) || isOpen(searchOverlay) || isOpen(notifDrawer) ? 'hidden' : '';
  };

  /* ------------------------------------------------------------------
     Genre pills
  ------------------------------------------------------------------ */
  const pillRow = $('pillRow');
  pillRow.innerHTML =
    `<button class="pill active" data-genre="">For you</button>` +
    getGenres().slice(0, 6).map((g) => `<button class="pill" data-genre="${escapeHtml(g.name)}">${escapeHtml(g.name)}</button>`).join('');

  /* ------------------------------------------------------------------
     Hero carousel
  ------------------------------------------------------------------ */
  const heroTrack = $('heroTrack'), heroDots = $('heroDots');
  byRating.slice(0, 4).forEach((it, i) => {
    const slide = document.createElement('div');
    slide.className = 'hero-slide';
    slide.innerHTML = `<div class="hero-slide-bg">${posterBg(it)}</div>
      <div class="hero-slide-content">
        <div class="hero-eyebrow">${it.status === 'Airing' ? 'Currently airing' : 'Spotlight'}</div>
        <div class="hero-slide-title">${escapeHtml(it.title)}</div>
        <div class="hero-slide-meta">${it.year} · ${it.episodes} eps · ★ ${it.rating}</div>
        <div class="hero-slide-actions">
          <button class="btn btn-primary" data-open="${it.id}">Watch</button>
          <button class="btn btn-ghost" data-open="${it.id}">Details</button>
        </div>
      </div>`;
    heroTrack.appendChild(slide);
    const dot = document.createElement('div');
    dot.className = 'dot' + (i === 0 ? ' active' : '');
    heroDots.appendChild(dot);
  });

  function updateHero() {
    const slides = [...heroTrack.children];
    if (!slides.length) return;
    const center = heroTrack.scrollLeft + heroTrack.clientWidth / 2;
    let nearest = 0, best = Infinity;
    slides.forEach((s, i) => {
      const dist = Math.abs(center - (s.offsetLeft + s.offsetWidth / 2));
      if (dist < best) { best = dist; nearest = i; }
      s.style.transform = `scale(${1 - Math.min(1, dist / heroTrack.clientWidth) * 0.08})`;
    });
    [...heroDots.children].forEach((d, i) => d.classList.toggle('active', i === nearest));
  }
  heroTrack.addEventListener('scroll', updateHero, { passive: true });
  updateHero();

  /* ------------------------------------------------------------------
     Rows
  ------------------------------------------------------------------ */
  const rowsEl = $('rows');
  function renderRows(genre) {
    rowsEl.innerHTML = '';
    let shown = 0;
    rowDefs.forEach((row) => {
      const items = genre ? row.items.filter((it) => it.genres.includes(genre)) : row.items;
      if (!items.length) return;
      shown++;
      const section = document.createElement('section');
      section.className = 'row reveal';
      section.setAttribute('aria-label', row.title);
      section.innerHTML = `<div class="row-head"><h2 class="row-title">${row.title}</h2>
        <span class="row-more">${items.length} title${items.length === 1 ? '' : 's'}</span></div>
        <div class="row-track">${items.map((it) => {
          const badge = badgeFor(it);
          return `<button class="card" data-open="${it.id}" aria-label="${escapeHtml(it.title)}, ${it.year}, rated ${it.rating}">
            <div class="card-art">${posterBg(it)}
              ${badge ? `<span class="card-badge">${badge}</span>` : ''}
              ${row.progress ? `<div class="card-progress"><i style="width:${Math.round((it.progress || 0) * 100)}%"></i></div>` : ''}
            </div>
            <div class="card-title">${escapeHtml(it.title)}</div>
            <div class="card-meta">${it.year} · ★ ${it.rating}</div></button>`;
        }).join('')}</div>`;
      rowsEl.appendChild(section);
    });
    if (!shown) {
      rowsEl.innerHTML = `<div class="empty-note">No titles in “${escapeHtml(genre)}” yet.<br>
        <button class="btn btn-ghost" style="margin-top:14px" data-genre-reset>Show everything</button></div>`;
    }
    observeReveals();
  }

  let revealObserver = null;
  function observeReveals() {
    const els = rowsEl.querySelectorAll('.reveal');
    if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      els.forEach((el) => el.classList.add('in'));
      return;
    }
    revealObserver = revealObserver || new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('in'); revealObserver.unobserve(e.target); } });
    }, { threshold: 0.12 });
    els.forEach((el) => revealObserver.observe(el));
  }

  function setGenre(genre) {
    pillRow.querySelectorAll('.pill').forEach((p) => p.classList.toggle('active', p.dataset.genre === genre));
    renderRows(genre);
  }

  /* ------------------------------------------------------------------
     Detail sheet
  ------------------------------------------------------------------ */
  let currentId = null;
  const inWatchlist = (id) => storage.get('watchlist', []).includes(id);
  function syncListButton() {
    const on = currentId && inWatchlist(currentId);
    $('sheetListBtn').textContent = on ? '✓ In list' : '+ List';
    $('sheetListBtn').setAttribute('aria-pressed', on ? 'true' : 'false');
  }

  function openSheet(id, trigger) {
    const it = findTitle(id);
    if (!it) { toast('That title is unavailable', 'error'); return; }
    currentId = id;
    lastTrigger = trigger || null;
    $('sheetHeroBg').innerHTML = posterBg(it);
    $('sheetEyebrow').textContent = it.status;
    $('sheetTitle').textContent = it.title;
    $('sheetAlt').textContent = it.altTitle || '';
    $('sheetMeta').innerHTML = `<span>${it.year}</span><span>${it.episodes} episodes</span><span>★ ${it.rating}</span><span>${escapeHtml(it.studio)}</span>`;
    $('sheetDesc').textContent = it.description;
    $('genreChips').innerHTML = [...it.genres, ...(it.themes || [])].map((g) => `<span class="chip">${escapeHtml(g)}</span>`).join('');
    $('infoGrid').innerHTML = `
      <dt>Status</dt><dd>${escapeHtml(it.status)}</dd>
      <dt>Season</dt><dd>${escapeHtml(it.season || '—')}</dd>
      <dt>Runtime</dt><dd>${it.runtime} min</dd>
      <dt>Tone</dt><dd>${escapeHtml(it.tone || '—')}</dd>
      <dt>Pacing</dt><dd>${escapeHtml(it.pacing || '—')}</dd>
      <dt>Studio</dt><dd>${escapeHtml(it.studio)}</dd>`;
    const shownEps = Math.min(it.episodes, 8);
    $('epList').innerHTML = Array.from({ length: shownEps }, (_, i) =>
      `<div class="ep"><span class="ep-num">${String(i + 1).padStart(2, '0')}</span><span class="ep-title">Episode ${i + 1}</span><span class="ep-dur">${it.runtime} min</span></div>`
    ).join('') + (it.episodes > shownEps ? `<div class="ep"><span class="ep-title" style="color:var(--text-faint)">+ ${it.episodes - shownEps} more episodes</span></div>` : '');
    syncListButton();
    sheet.scrollTop = 0;
    sheet.classList.add('open');
    backdrop.classList.add('open');
    sheet.setAttribute('aria-hidden', 'false');
    syncScrollLock();
    $('sheetClose').focus({ preventScroll: true });
  }

  function closeSheet() {
    sheet.classList.remove('open');
    backdrop.classList.remove('open');
    sheet.setAttribute('aria-hidden', 'true');
    syncScrollLock();
    if (lastTrigger && document.contains(lastTrigger)) lastTrigger.focus({ preventScroll: true });
  }

  /* ------------------------------------------------------------------
     Search (filters the real catalog)
  ------------------------------------------------------------------ */
  function renderSearch(query) {
    const q = query.trim().toLowerCase();
    if (!q) {
      searchResults.innerHTML = `<p class="search-hint">Search by title, genre or studio.</p>
        <div class="chip-row">${getGenres().slice(0, 6).map((g) => `<button class="chip" data-search="${escapeHtml(g.name)}">${escapeHtml(g.name)}</button>`).join('')}</div>`;
      return;
    }
    const matches = catalog.filter((it) =>
      it.title.toLowerCase().includes(q) || (it.altTitle || '').toLowerCase().includes(q) ||
      it.studio.toLowerCase().includes(q) || it.genres.some((g) => g.toLowerCase().includes(q)));
    searchResults.innerHTML = matches.length
      ? matches.map((it) => `<button class="search-row" data-open="${it.id}" data-close-search>
          <div class="search-row-art">${posterBg(it)}</div>
          <div><div class="search-row-title">${escapeHtml(it.title)}</div>
          <div class="search-row-meta">${it.year} · ${escapeHtml(it.genres[0])} · ★ ${it.rating}</div></div></button>`).join('')
      : `<div class="search-empty">No titles match “${escapeHtml(query)}”.<br>
          <button class="btn btn-ghost" style="margin-top:14px" data-search="">Clear search</button></div>`;
  }
  const renderSearchDebounced = debounce((v) => renderSearch(v), 150);

  function openSearch(trigger) {
    lastTrigger = trigger || null;
    renderSearch(searchInput.value);
    searchOverlay.classList.add('open');
    searchOverlay.setAttribute('aria-hidden', 'false');
    syncScrollLock();
    setTimeout(() => searchInput.focus(), 200);
  }
  function closeSearch() {
    searchOverlay.classList.remove('open');
    searchOverlay.setAttribute('aria-hidden', 'true');
    searchInput.value = '';
    syncScrollLock();
  }

  /* ------------------------------------------------------------------
     Notifications
  ------------------------------------------------------------------ */
  function renderNotifs() {
    const list = getNotifications();
    notifList.innerHTML = list.length ? list.map((n) => `
      <div class="notif-item">
        <span class="notif-dot ${n.unread ? '' : 'read'}" aria-label="${n.unread ? 'Unread' : 'Read'}"></span>
        <div><div class="notif-title">${escapeHtml(n.title)}</div>
        <div class="notif-body">${escapeHtml(n.body)}</div>
        <div class="notif-time">${escapeHtml(n.time)}</div></div></div>`).join('')
      : `<div class="empty-note">You’re all caught up.</div>`;
    $('notifBadge').style.display = list.some((n) => n.unread) ? 'block' : 'none';
  }
  function openNotifs(trigger) {
    lastTrigger = trigger || null;
    notifDrawer.classList.add('open');
    notifDrawer.setAttribute('aria-hidden', 'false');
    syncScrollLock();
    $('notifCloseBtn').focus({ preventScroll: true });
  }
  function closeNotifs() {
    notifDrawer.classList.remove('open');
    notifDrawer.setAttribute('aria-hidden', 'true');
    syncScrollLock();
    if (lastTrigger && document.contains(lastTrigger)) lastTrigger.focus({ preventScroll: true });
  }

  /* ------------------------------------------------------------------
     Event wiring (delegated — no inline handlers)
  ------------------------------------------------------------------ */
  document.addEventListener('click', (e) => {
    const t = e.target;
    const open = t.closest('[data-open]');
    if (open) {
      if (open.hasAttribute('data-close-search')) closeSearch();
      openSheet(open.dataset.open, open.hasAttribute('data-close-search') ? $('searchOpenBtn') : open);
      return;
    }
    const genre = t.closest('#pillRow .pill');
    if (genre) return setGenre(genre.dataset.genre);
    if (t.closest('[data-genre-reset]')) return setGenre('');
    const chip = t.closest('[data-search]');
    if (chip) { searchInput.value = chip.dataset.search; renderSearch(searchInput.value); searchInput.focus(); return; }
    const act = t.closest('[data-action]');
    if (!act) return;
    switch (act.dataset.action) {
      case 'home': window.scrollTo({ top: 0, behavior: 'smooth' }); break;
      case 'top': window.scrollTo({ top: 0, behavior: 'smooth' }); break;
      case 'feedback': toast('Thanks — feedback isn’t wired to a backend in this demo', 'info'); break;
      case 'mark-read': getNotifications().forEach((n) => { n.unread = false; }); renderNotifs(); toast('All caught up', 'success'); break;
    }
  });

  $('sheetClose').addEventListener('click', closeSheet);
  backdrop.addEventListener('click', closeSheet);
  $('sheetWatchBtn').addEventListener('click', () => toast('Playback requires licensed media (demo)', 'info'));
  $('sheetListBtn').addEventListener('click', () => { if (currentId) { addToWatchlist(currentId); syncListButton(); } });
  $('searchOpenBtn').addEventListener('click', (e) => openSearch(e.currentTarget));
  $('searchCloseBtn').addEventListener('click', closeSearch);
  searchInput.addEventListener('input', (e) => renderSearchDebounced(e.target.value));
  $('notifOpenBtn').addEventListener('click', (e) => openNotifs(e.currentTarget));
  $('notifCloseBtn').addEventListener('click', closeNotifs);

  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (isOpen(notifDrawer)) closeNotifs();
    else if (isOpen(sheet)) closeSheet();
    else if (isOpen(searchOverlay)) closeSearch();
  });

  const topbar = $('topbar');
  window.addEventListener('scroll', () => topbar.classList.toggle('solid', window.scrollY > 10), { passive: true });

  /* ------------------------------------------------------------------
     Boot
  ------------------------------------------------------------------ */
  renderRows('');
  renderNotifs();
})();
