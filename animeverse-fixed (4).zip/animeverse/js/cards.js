/**
 * Card rendering + Swiper carousels
 */

function createAnimeCard(item, options = {}) {
  const { showProgress = false, wide = false } = options;
  const slide = document.createElement('div');
  slide.className = 'swiper-slide';
  slide.style.width = wide ? '320px' : '160px';
  if (window.innerWidth >= 640) slide.style.width = wide ? '380px' : '180px';
  if (window.innerWidth >= 1024) slide.style.width = wide ? '420px' : '200px';

  if (wide) {
    slide.innerHTML = `
      <div class="continue-card group" data-id="${item.id}">
        <div class="absolute inset-0 bg-gradient-to-br ${item.posterGradient}">
          <div class="absolute inset-0 opacity-30" style="background-image: radial-gradient(circle at 70% 30%, rgba(255,255,255,0.2) 0%, transparent 50%);"></div>
        </div>
        <div class="absolute inset-0 bg-gradient-to-t from-void-950 via-void-950/40 to-transparent"></div>
        <div class="absolute bottom-0 left-0 right-0 p-4">
          <p class="font-display font-semibold text-white text-sm sm:text-base truncate">${item.title}</p>
          <p class="text-xs text-void-400 mt-0.5">Ep ${Math.ceil((item.progress || 0) * (item.episodes || 12))} of ${item.episodes || '—'} · ${item.genres?.[0] || ''}</p>
          <div class="progress-track mt-2">
            <div class="progress-fill" style="width: ${(item.progress || 0) * 100}%"></div>
          </div>
        </div>
        <button class="absolute top-3 right-3 p-2 rounded-full bg-black/40 text-white opacity-0 group-hover:opacity-100 transition-opacity play-btn" data-id="${item.id}" aria-label="Play">
          <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
        </button>
      </div>
    `;
  } else {
    slide.innerHTML = `
      <div class="anime-card" data-id="${item.id}">
        <div class="card-poster absolute inset-0 bg-gradient-to-br ${item.posterGradient}">
          <div class="absolute inset-0 opacity-25" style="background-image: radial-gradient(circle at 40% 30%, rgba(255,255,255,0.2) 0%, transparent 55%);"></div>
        </div>
        <div class="card-overlay">
          <p class="font-display font-semibold text-sm text-white leading-tight line-clamp-2">${item.title}</p>
          <div class="flex items-center gap-2 mt-1 text-[11px] text-void-300">
            <span>${item.year}</span>
            ${item.rating ? `<span class="text-amber-400">★ ${item.rating}</span>` : ''}
            <span>${item.type === 'movie' ? formatRuntime(item.runtime) : (item.episodes ? item.episodes + ' eps' : '')}</span>
          </div>
          <div class="card-actions mt-2">
            <button class="play-btn flex-1 py-1.5 rounded-lg bg-white text-void-950 text-xs font-semibold flex items-center justify-center gap-1" data-id="${item.id}">
              <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg> Play
            </button>
            <button class="fav-btn p-1.5 rounded-lg bg-white/15 text-white hover:bg-white/25" data-id="${item.id}" aria-label="Favorite">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
            </button>
          </div>
        </div>
        <!-- Always-visible bottom strip for mobile -->
        <div class="absolute bottom-0 left-0 right-0 p-2.5 bg-gradient-to-t from-void-950/95 to-transparent lg:opacity-0 pointer-events-none lg:pointer-events-auto">
          <p class="text-xs font-medium text-white truncate">${item.title}</p>
        </div>
      </div>
    `;
  }

  // Bind events
  const card = slide.querySelector('[data-id]');
  card?.addEventListener('click', (e) => {
    if (e.target.closest('.play-btn') || e.target.closest('.fav-btn')) return;
    if (window.openDetail) window.openDetail(item.id);
  });
  slide.querySelectorAll('.play-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const it = getById(btn.dataset.id);
      if (window.openPlayer) window.openPlayer(it);
    });
  });
  slide.querySelectorAll('.fav-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleFavorite(btn.dataset.id);
    });
  });

  return slide;
}

function createListRow(item) {
  const row = document.createElement('div');
  row.className = 'list-row';
  row.dataset.id = item.id;
  row.innerHTML = `
    <div class="w-14 h-20 rounded-lg flex-shrink-0 bg-gradient-to-br ${item.posterGradient} relative overflow-hidden">
      <div class="absolute inset-0 opacity-30" style="background-image: radial-gradient(circle at 40% 30%, rgba(255,255,255,0.25) 0%, transparent 50%);"></div>
    </div>
    <div class="flex-1 min-w-0 py-0.5">
      <p class="font-medium text-sm text-white truncate">${item.title}</p>
      <p class="text-xs text-void-400 mt-0.5">${item.year} · ${item.genres?.slice(0, 2).join(' · ') || ''}</p>
      <div class="flex items-center gap-2 mt-1.5">
        ${item.rating ? `<span class="text-[11px] text-amber-400">★ ${item.rating}</span>` : '<span class="text-[11px] text-void-500">TBA</span>'}
        <span class="text-[11px] text-void-500">${item.status}</span>
      </div>
    </div>
  `;
  row.addEventListener('click', () => window.openDetail?.(item.id));
  return row;
}

function initSwipers() {
  const configs = [
    { el: '.continue-swiper', list: CONTINUE, target: 'continue-list', wide: true, opts: { slidesPerView: 'auto', spaceBetween: 16 } },
    { el: '.trending-swiper', list: TRENDING, target: 'trending-list', opts: { slidesPerView: 'auto', spaceBetween: 14, navigation: { nextEl: '.swiper-next-trending', prevEl: '.swiper-prev-trending' } } },
    { el: '.releases-swiper', list: NEW_RELEASES, target: 'releases-list', opts: { slidesPerView: 'auto', spaceBetween: 14 } },
    { el: '.popular-swiper', list: POPULAR, target: 'popular-list', opts: { slidesPerView: 'auto', spaceBetween: 14 } },
    { el: '.airing-swiper', list: AIRING, target: 'airing-list', opts: { slidesPerView: 'auto', spaceBetween: 14 } },
    { el: '.movies-swiper', list: MOVIES, target: 'movies-list', opts: { slidesPerView: 'auto', spaceBetween: 14 } },
    { el: '.series-swiper', list: SERIES, target: 'series-list', opts: { slidesPerView: 'auto', spaceBetween: 14 } },
    { el: '.gems-swiper', list: GEMS, target: 'gems-list', opts: { slidesPerView: 'auto', spaceBetween: 14 } },
    { el: '.rated-swiper', list: RATED, target: 'rated-list', opts: { slidesPerView: 'auto', spaceBetween: 14 } },
    { el: '.classics-swiper', list: CLASSICS, target: 'classics-list', opts: { slidesPerView: 'auto', spaceBetween: 14 } },
    { el: '.upcoming-swiper', list: UPCOMING, target: 'upcoming-list', opts: { slidesPerView: 'auto', spaceBetween: 14 } },
  ];

  configs.forEach(({ el, list, target, wide, opts }) => {
    const wrapper = document.getElementById(target);
    if (!wrapper || !list) return;
    list.forEach(item => {
      wrapper.appendChild(createAnimeCard(item, { wide, showProgress: wide }));
    });
    if (typeof Swiper !== 'undefined') {
      new Swiper(el, {
        ...opts,
        freeMode: true,
        grabCursor: true,
        breakpoints: {
          0: { spaceBetween: 12 },
          640: { spaceBetween: 14 },
          1024: { spaceBetween: 16 },
        },
      });
    }
  });

  // Seasonal & Recommended lists
  const seasonal = document.getElementById('seasonal-list');
  SEASONAL.forEach(item => seasonal?.appendChild(createListRow(item)));
  const recommended = document.getElementById('recommended-list');
  RECOMMENDED.forEach(item => recommended?.appendChild(createListRow(item)));

  // Genres grid
  const genresGrid = document.getElementById('genres-grid');
  GENRES.forEach(g => {
    const card = document.createElement('button');
    card.className = 'genre-card flex items-center justify-center';
    card.innerHTML = `
      <div class="genre-bg bg-gradient-to-br ${g.color}"></div>
      <span class="text-white">${g.name}</span>
    `;
    card.addEventListener('click', () => {
      toast(`Browsing ${g.name}`, 'info');
      // In production: filter catalog by genre
    });
    genresGrid?.appendChild(card);
  });
}

function initDNABars() {
  document.querySelectorAll('.dna-bar').forEach(bar => {
    const value = bar.dataset.value || 0;
    const fill = document.createElement('div');
    fill.className = 'fill';
    // Insert into the ::after track via a real element
    bar.style.position = 'relative';
    const track = document.createElement('div');
    track.className = 'flex-1 h-1.5 bg-void-800 rounded-full overflow-hidden relative';
    track.appendChild(fill);
    // Rebuild structure cleanly
    const label = bar.dataset.label;
    bar.innerHTML = '';
    bar.className = 'flex items-center gap-3';
    const labelEl = document.createElement('span');
    labelEl.className = 'text-[11px] text-void-400 w-16 text-right flex-shrink-0';
    labelEl.textContent = label;
    bar.appendChild(labelEl);
    bar.appendChild(track);
    // Animate on scroll into view
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          fill.style.width = value + '%';
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.3 });
    observer.observe(bar);
  });
}
