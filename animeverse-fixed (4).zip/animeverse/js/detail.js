/**
 * Cinematic title detail view
 */

function initDetail() {
  const overlay = document.getElementById('detail-overlay');
  const content = document.getElementById('detail-content');
  const closeBtn = document.getElementById('detail-close');

  closeBtn?.addEventListener('click', closeDetail);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !overlay.classList.contains('opacity-0')) closeDetail();
  });

  function closeDetail() {
    overlay.classList.add('opacity-0', 'pointer-events-none');
    overlay.classList.remove('opacity-100');
    document.body.style.overflow = '';
  }

  window.openDetail = function (id) {
    const item = getById(id);
    if (!item || !content) return;

    content.innerHTML = `
      <div class="relative min-h-[70vh]">
        <div class="detail-backdrop absolute inset-0 bg-gradient-to-br ${item.backdropGradient || item.posterGradient}"></div>
        <div class="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
          <div class="flex flex-col md:flex-row gap-8 lg:gap-12">
            <div class="w-40 sm:w-48 md:w-56 flex-shrink-0 mx-auto md:mx-0">
              <div class="aspect-[2/3] rounded-xl overflow-hidden shadow-card bg-gradient-to-br ${item.posterGradient} relative">
                <div class="absolute inset-0 opacity-30" style="background-image: radial-gradient(circle at 40% 30%, rgba(255,255,255,0.25) 0%, transparent 50%);"></div>
              </div>
            </div>
            <div class="flex-1 text-center md:text-left">
              <p class="text-xs tracking-[0.2em] uppercase text-aurora-400 mb-2">${item.type} · ${item.status}</p>
              <h1 class="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-white tracking-tight mb-1">${item.title}</h1>
              ${item.altTitle ? `<p class="text-void-400 text-sm mb-4">${item.altTitle}</p>` : '<div class="mb-4"></div>'}
              <div class="flex flex-wrap items-center justify-center md:justify-start gap-3 text-sm text-void-300 mb-5">
                <span>${item.year}</span>
                ${item.rating ? `<span class="text-amber-400">★ ${item.rating}</span>` : ''}
                <span>${item.type === 'movie' ? formatRuntime(item.runtime) : item.episodes + ' episodes'}</span>
                <span>${item.studio}</span>
              </div>
              <div class="flex flex-wrap gap-2 justify-center md:justify-start mb-6">
                ${item.genres.map(g => `<span class="px-2.5 py-1 rounded-full text-xs bg-white/10 text-void-200">${g}</span>`).join('')}
              </div>
              <p class="text-void-300 leading-relaxed max-w-2xl mb-8 text-sm sm:text-base">${item.description}</p>
              <div class="flex flex-wrap gap-3 justify-center md:justify-start">
                <button id="detail-watch" class="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white text-void-950 font-semibold text-sm hover:scale-[1.02] transition-transform">
                  <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                  WATCH NOW
                </button>
                <button id="detail-watchlist" class="inline-flex items-center gap-2 px-5 py-3 rounded-xl border border-white/20 text-white text-sm font-medium hover:bg-white/10 transition-all">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"/></svg>
                  Watchlist
                </button>
                <button id="detail-trailer" class="inline-flex items-center gap-2 px-5 py-3 rounded-xl border border-white/20 text-white text-sm font-medium hover:bg-white/10 transition-all">
                  Trailer
                </button>
                <button id="detail-share" class="p-3 rounded-xl border border-white/20 text-white hover:bg-white/10 transition-all" aria-label="Share">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"/></svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Sections -->
      <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pb-20 space-y-12">
        <!-- Anime DNA -->
        <section>
          <h2 class="font-display font-bold text-xl mb-5">Anime DNA</h2>
          <div class="grid sm:grid-cols-2 gap-6 p-5 rounded-2xl bg-void-900/40 border border-void-800/50">
            <div class="space-y-3">
              ${(item.genres || []).map((g, i) => {
                const vals = [90, 75, 60, 85, 70];
                return `<div class="flex items-center gap-3">
                  <span class="text-xs text-void-400 w-20 text-right">${g}</span>
                  <div class="flex-1 h-1.5 bg-void-800 rounded-full overflow-hidden">
                    <div class="h-full bg-gradient-to-r from-aurora-600 to-cyan-500 rounded-full" style="width:${vals[i % vals.length]}%"></div>
                  </div>
                </div>`;
              }).join('')}
            </div>
            <div class="space-y-2 text-sm">
              <p><span class="text-void-500">Tone:</span> <span class="text-void-200">${item.tone || '—'}</span></p>
              <p><span class="text-void-500">Pacing:</span> <span class="text-void-200">${item.pacing || '—'}</span></p>
              <p><span class="text-void-500">Themes:</span> <span class="text-void-200">${(item.themes || []).join(', ')}</span></p>
              <p><span class="text-void-500">Studio:</span> <span class="text-void-200">${item.studio}</span></p>
            </div>
          </div>
        </section>

        <!-- Episodes (placeholder) -->
        ${item.type === 'series' ? `
        <section>
          <h2 class="font-display font-bold text-xl mb-5">Episodes</h2>
          <div class="space-y-2">
            ${Array.from({ length: Math.min(item.episodes || 6, 6) }, (_, i) => `
              <button class="w-full flex items-center gap-4 p-3 rounded-xl bg-void-900/40 border border-void-800/40 hover:border-aurora-500/30 text-left transition-all episode-btn" data-ep="${i + 1}">
                <span class="text-void-500 text-sm w-8">${String(i + 1).padStart(2, '0')}</span>
                <div class="flex-1 min-w-0">
                  <p class="text-sm font-medium text-white truncate">Episode ${i + 1}</p>
                  <p class="text-xs text-void-500">${item.runtime || 24} min</p>
                </div>
                <svg class="w-5 h-5 text-void-400" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
              </button>
            `).join('')}
          </div>
        </section>
        ` : ''}

        <!-- Similar -->
        <section>
          <h2 class="font-display font-bold text-xl mb-5">Similar Titles</h2>
          <div class="flex gap-3 overflow-x-auto pb-2 custom-scrollbar">
            ${CATALOG.filter(a => a.id !== item.id && a.genres.some(g => item.genres.includes(g))).slice(0, 6).map(a => `
              <button class="flex-shrink-0 w-28 similar-card" data-id="${a.id}">
                <div class="aspect-[2/3] rounded-lg bg-gradient-to-br ${a.posterGradient} mb-2"></div>
                <p class="text-xs font-medium text-void-200 truncate">${a.title}</p>
              </button>
            `).join('')}
          </div>
        </section>

        <!-- Reviews -->
        <section>
          <div class="flex items-center justify-between mb-5">
            <h2 class="font-display font-bold text-xl">Reviews</h2>
            <a href="pages/community.html" class="text-sm text-aurora-400 hover:text-aurora-300">View all →</a>
          </div>
          <div class="space-y-3">
            <div class="p-4 rounded-xl bg-void-900/40 border border-void-800/40">
              <div class="flex items-center gap-2 mb-2">
                <div class="w-8 h-8 rounded-full bg-gradient-to-br from-aurora-500 to-cyan-500 flex items-center justify-center text-xs font-bold">N</div>
                <span class="text-sm font-medium">NovaWatcher</span>
                <span class="text-xs text-amber-400">★ 9/10</span>
              </div>
              <p class="text-sm text-void-300 leading-relaxed">A standout entry — balances spectacle with character. Highly recommended for fans of ${item.genres?.[0] || 'this genre'}.</p>
            </div>
            <div class="p-4 rounded-xl bg-void-900/40 border border-void-800/40">
              <div class="flex items-center gap-2 mb-2">
                <div class="w-8 h-8 rounded-full bg-gradient-to-br from-ember-500 to-rose-700 flex items-center justify-center text-xs font-bold">S</div>
                <span class="text-sm font-medium">SakuraCode</span>
                <span class="text-xs text-amber-400">★ 8/10</span>
                <span class="text-xs px-1.5 py-0.5 rounded bg-orange-500/20 text-orange-300">Spoiler</span>
              </div>
              <p class="text-sm text-void-500 mb-1">Click to reveal spoiler</p>
              <p class="detail-spoiler text-sm text-void-300 leading-relaxed cursor-pointer" style="filter:blur(5px);user-select:none">The mid-season twist reframes everything — rewatch episode 6 with this in mind.</p>
            </div>
          </div>
        </section>

        <!-- Info -->
        <section>
          <h2 class="font-display font-bold text-xl mb-5">Information</h2>
          <dl class="grid sm:grid-cols-2 gap-3 text-sm">
            <div class="flex justify-between sm:block p-3 rounded-lg bg-void-900/30"><dt class="text-void-500">Status</dt><dd class="text-void-200">${item.status}</dd></div>
            <div class="flex justify-between sm:block p-3 rounded-lg bg-void-900/30"><dt class="text-void-500">Studio</dt><dd class="text-void-200">${item.studio}</dd></div>
            <div class="flex justify-between sm:block p-3 rounded-lg bg-void-900/30"><dt class="text-void-500">Year</dt><dd class="text-void-200">${item.year}</dd></div>
            <div class="flex justify-between sm:block p-3 rounded-lg bg-void-900/30"><dt class="text-void-500">Type</dt><dd class="text-void-200">${item.type}</dd></div>
          </dl>
        </section>
      </div>
    `;

    // Bind buttons
    content.querySelector('#detail-watch')?.addEventListener('click', () => {
      closeDetail();
      window.openPlayer?.(item);
    });
    content.querySelector('#detail-watchlist')?.addEventListener('click', () => addToWatchlist(item.id));
    content.querySelector('#detail-trailer')?.addEventListener('click', () => toast('Trailer (demo — licensed media only)', 'info'));
    content.querySelector('#detail-share')?.addEventListener('click', () => {
      navigator.clipboard?.writeText(window.location.href + '#' + item.id);
      toast('Link copied', 'success');
    });
    content.querySelectorAll('.episode-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        closeDetail();
        window.openPlayer?.(item);
      });
    });
    content.querySelectorAll('.similar-card').forEach(btn => {
      btn.addEventListener('click', () => window.openDetail?.(btn.dataset.id));
    });
    content.querySelectorAll('.detail-spoiler').forEach(el => {
      el.addEventListener('click', () => {
        el.style.filter = 'none';
        el.style.userSelect = 'auto';
        const hint = el.previousElementSibling;
        if (hint) hint.textContent = 'Spoiler revealed';
      });
    });

    overlay.classList.remove('opacity-0', 'pointer-events-none');
    overlay.classList.add('opacity-100');
    document.body.style.overflow = 'hidden';
    overlay.scrollTop = 0;
  };
}
