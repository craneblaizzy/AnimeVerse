/**
 * Global cinematic search overlay
 */

function initSearch() {
  const overlay = document.getElementById('search-overlay');
  const input = document.getElementById('search-input');
  const resultsList = document.getElementById('search-results-list');
  const trendingEl = document.getElementById('trending-searches');
  const openBtn = document.getElementById('search-btn');
  const closeBtn = document.getElementById('search-close');

  if (!overlay || !input) return;

  // Trending chips
  TRENDING_SEARCHES.forEach(term => {
    const chip = document.createElement('button');
    chip.className = 'px-3 py-1.5 rounded-full text-xs bg-void-800/60 text-void-300 border border-void-700/50 hover:border-aurora-500/40 hover:text-white transition-all';
    chip.textContent = term;
    chip.addEventListener('click', () => {
      input.value = term;
      input.dispatchEvent(new Event('input'));
      input.focus();
    });
    trendingEl?.appendChild(chip);
  });

  function openSearch() {
    overlay.classList.remove('opacity-0', 'pointer-events-none');
    overlay.classList.add('opacity-100');
    setTimeout(() => input.focus(), 50);
    document.body.style.overflow = 'hidden';
  }

  function closeSearch() {
    overlay.classList.add('opacity-0', 'pointer-events-none');
    overlay.classList.remove('opacity-100');
    input.value = '';
    resultsList.innerHTML = '';
    document.body.style.overflow = '';
  }

  openBtn?.addEventListener('click', openSearch);
  closeBtn?.addEventListener('click', closeSearch);
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeSearch();
  });

  // Keyboard: / to open, Esc to close
  document.addEventListener('keydown', (e) => {
    if (e.key === '/' && !['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)) {
      e.preventDefault();
      openSearch();
    }
    if (e.key === 'Escape') closeSearch();
  });

  // Filters
  let activeFilter = 'all';
  document.querySelectorAll('.search-filter').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.search-filter').forEach(b => {
        b.classList.remove('active', 'bg-aurora-600/20', 'text-aurora-300', 'border-aurora-500/30');
        b.classList.add('bg-void-800/50', 'text-void-400', 'border-void-700/50');
      });
      btn.classList.add('active', 'bg-aurora-600/20', 'text-aurora-300', 'border-aurora-500/30');
      btn.classList.remove('bg-void-800/50', 'text-void-400', 'border-void-700/50');
      activeFilter = btn.textContent.trim().toLowerCase();
      performSearch(input.value);
    });
  });

  const performSearch = debounce((query) => {
    resultsList.innerHTML = '';
    if (!query || query.length < 1) return;

    const q = query.toLowerCase();
    let results = CATALOG.filter(item => {
      const match =
        item.title.toLowerCase().includes(q) ||
        item.altTitle?.toLowerCase().includes(q) ||
        item.genres?.some(g => g.toLowerCase().includes(q)) ||
        item.studio?.toLowerCase().includes(q) ||
        item.description?.toLowerCase().includes(q);
      if (!match) return false;
      if (activeFilter === 'all') return true;
      if (activeFilter === 'anime' || activeFilter === 'series') return item.type === 'series';
      if (activeFilter === 'movies') return item.type === 'movie';
      if (activeFilter === 'genres') return item.genres?.some(g => g.toLowerCase().includes(q));
      if (activeFilter === 'studios') return item.studio?.toLowerCase().includes(q);
      return true;
    });

    // Character matches
    const charMatches = CHARACTERS.filter(c =>
      c.name.toLowerCase().includes(q) || c.anime.toLowerCase().includes(q)
    );

    if (results.length === 0 && charMatches.length === 0) {
      resultsList.innerHTML = `
        <div class="py-12 text-center">
          <p class="text-void-400 mb-2">No results for “${query}”</p>
          <p class="text-sm text-void-500">Try a different title, genre, or studio</p>
        </div>
      `;
      return;
    }

    results.slice(0, 12).forEach(item => {
      const row = document.createElement('button');
      row.className = 'w-full flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 text-left transition-colors';
      row.innerHTML = `
        <div class="w-10 h-14 rounded-md bg-gradient-to-br ${item.posterGradient} flex-shrink-0"></div>
        <div class="min-w-0 flex-1">
          <p class="font-medium text-sm text-white truncate">${item.title}</p>
          <p class="text-xs text-void-400">${item.type} · ${item.year} · ${item.genres?.slice(0, 2).join(', ')}</p>
        </div>
        ${item.rating ? `<span class="text-xs text-amber-400">★ ${item.rating}</span>` : ''}
      `;
      row.addEventListener('click', () => {
        closeSearch();
        window.openDetail?.(item.id);
      });
      resultsList.appendChild(row);
    });

    if (charMatches.length && (activeFilter === 'all' || activeFilter === 'characters')) {
      const header = document.createElement('p');
      header.className = 'text-xs uppercase tracking-wider text-void-500 mt-4 mb-2 px-1';
      header.textContent = 'Characters';
      resultsList.appendChild(header);
      charMatches.slice(0, 5).forEach(c => {
        const row = document.createElement('button');
        row.className = 'w-full flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 text-left transition-colors';
        row.innerHTML = `
          <div class="w-10 h-10 rounded-full bg-void-700 flex-shrink-0"></div>
          <div>
            <p class="font-medium text-sm text-white">${c.name}</p>
            <p class="text-xs text-void-400">${c.role} · ${c.anime}</p>
          </div>
        `;
        row.addEventListener('click', () => {
          closeSearch();
          toast(`Character: ${c.name}`, 'info');
        });
        resultsList.appendChild(row);
      });
    }
  }, 220);

  input.addEventListener('input', (e) => performSearch(e.target.value));
}
