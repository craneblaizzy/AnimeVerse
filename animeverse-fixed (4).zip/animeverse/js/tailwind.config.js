/* AnimeVerse design tokens for the Tailwind CDN (used by app.html).
   Mirrors the inline config in index.html so gradient classes stored in
   data/mock.js (e.g. "to-void-950") and utils.js toasts resolve correctly. */
tailwind.config = {
  theme: {
    extend: {
      colors: {
        void: { 50:'#f4f4f6',100:'#e8e8ed',200:'#d1d1db',300:'#a9a9bc',400:'#7c7c96',500:'#5c5c78',600:'#484860',700:'#3b3b4e',800:'#2f2f3e',900:'#1a1a24',950:'#0a0a0f' },
        aurora: { 400:'#8f9af8', 500:'#6e7cf6', 600:'#4a54b8' },
        ember: { 400:'#f3b877', 500:'#f0a85c', 600:'#d6883a' },
        cyan: { 400:'#8891e8', 500:'#5b66c9' }
      }
    }
  }
};
