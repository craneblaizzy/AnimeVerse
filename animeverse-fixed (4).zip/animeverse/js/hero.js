/**
 * Cinematic Hero — particles + GSAP entrance
 */

function initHero() {
  const canvas = document.getElementById('hero-canvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  let w, h, particles = [];
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function resize() {
    w = canvas.width = canvas.offsetWidth * devicePixelRatio;
    h = canvas.height = canvas.offsetHeight * devicePixelRatio;
    ctx.scale(devicePixelRatio, devicePixelRatio);
  }

  function createParticles() {
    const count = prefersReduced ? 20 : Math.min(80, Math.floor((canvas.offsetWidth * canvas.offsetHeight) / 12000));
    particles = [];
    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * canvas.offsetWidth,
        y: Math.random() * canvas.offsetHeight,
        r: Math.random() * 1.8 + 0.4,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.2 - 0.05,
        a: Math.random() * 0.5 + 0.15,
      });
    }
  }

  function draw() {
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.offsetWidth, canvas.offsetHeight);
    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0) p.x = canvas.offsetWidth;
      if (p.x > canvas.offsetWidth) p.x = 0;
      if (p.y < 0) p.y = canvas.offsetHeight;
      if (p.y > canvas.offsetHeight) p.y = 0;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(143, 154, 248, ${p.a})`;
      ctx.fill();
    });
    // soft connections
    if (!prefersReduced) {
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 100) {
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = `rgba(110, 124, 246, ${0.08 * (1 - dist / 100)})`;
            ctx.stroke();
          }
        }
      }
    }
    requestAnimationFrame(draw);
  }

  resize();
  createParticles();
  if (!prefersReduced) draw();
  else {
    // static stars
    particles.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(143, 154, 248, ${p.a})`;
      ctx.fill();
    });
  }
  window.addEventListener('resize', () => { resize(); createParticles(); });

  // GSAP entrance sequence
  if (typeof gsap !== 'undefined') {
    const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });
    tl.to('#hero-label', { opacity: 1, y: 0, duration: 0.7, delay: 0.3 })
      .to('#hero-title', { opacity: 1, y: 0, duration: 0.9 }, '-=0.4')
      .to('#hero-desc', { opacity: 1, y: 0, duration: 0.7 }, '-=0.5')
      .to('#hero-ctas', { opacity: 1, y: 0, duration: 0.6 }, '-=0.4')
      .to('#hero-meta', { opacity: 1, y: 0, duration: 0.5 }, '-=0.3')
      .to('#scroll-indicator', { opacity: 1, duration: 0.6 }, '-=0.2');

    // Set initial y for animation
    gsap.set(['#hero-label', '#hero-title', '#hero-desc', '#hero-ctas', '#hero-meta'], { y: 24 });
  } else {
    ['hero-label', 'hero-title', 'hero-desc', 'hero-ctas', 'hero-meta', 'scroll-indicator'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.opacity = '1';
    });
  }

  // Sound toggle (visual only — no real audio in demo)
  const soundBtn = document.getElementById('sound-toggle');
  const soundOn = document.getElementById('sound-on');
  const soundOff = document.getElementById('sound-off');
  let muted = true;
  if (soundBtn) {
    soundBtn.addEventListener('click', () => {
      muted = !muted;
      soundOn.classList.toggle('hidden', muted);
      soundOff.classList.toggle('hidden', !muted);
      toast(muted ? 'Ambient sound muted' : 'Ambient sound on (demo)', 'info');
    });
  }

  // CTAs
  document.getElementById('watch-now-btn')?.addEventListener('click', () => {
    const featured = CATALOG[0];
    if (window.openPlayer) window.openPlayer(featured);
    else toast('Opening player…', 'info');
  });
  document.getElementById('explore-btn')?.addEventListener('click', () => {
    document.getElementById('universe')?.scrollIntoView({ behavior: 'smooth' });
  });
}
