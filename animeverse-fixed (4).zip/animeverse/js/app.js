/**
 * AnimeVerse — Main Application Bootstrap
 */

(function () {
  'use strict';

  // Loader
  const loader = document.getElementById('loader');
  const loaderBar = document.getElementById('loader-bar');
  let progress = 0;
  const loaderInterval = setInterval(() => {
    progress += Math.random() * 25 + 10;
    if (progress >= 100) {
      progress = 100;
      clearInterval(loaderInterval);
      if (loaderBar) loaderBar.style.width = '100%';
      setTimeout(() => {
        loader?.classList.add('opacity-0', 'pointer-events-none');
        setTimeout(() => loader?.remove(), 700);
        initApp();
      }, 200);
    } else if (loaderBar) {
      loaderBar.style.width = progress + '%';
    }
  }, 120);

  function initApp() {
    // Smooth scroll (Lenis)
    if (typeof Lenis !== 'undefined') {
      const lenis = new Lenis({
        duration: 1.1,
        easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        smoothWheel: true,
      });
      function raf(time) {
        lenis.raf(time);
        requestAnimationFrame(raf);
      }
      requestAnimationFrame(raf);
      // Respect reduced motion
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        lenis.destroy();
      }
    }

    // GSAP ScrollTrigger
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
      gsap.registerPlugin(ScrollTrigger);
    }

    // Nav scroll state + scroll progress
    const nav = document.getElementById('nav');
    const progressBar = document.getElementById('scroll-progress-bar');
    const onScroll = () => {
      if (window.scrollY > 40) nav?.classList.add('scrolled');
      else nav?.classList.remove('scrolled');
      if (progressBar) {
        const doc = document.documentElement;
        const max = doc.scrollHeight - doc.clientHeight;
        const pct = max > 0 ? (window.scrollY / max) * 100 : 0;
        progressBar.style.width = pct + '%';
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    // Keyboard shortcuts modal (?)
    const shortcutsModal = document.getElementById('shortcuts-modal');
    function openShortcuts() {
      shortcutsModal?.classList.remove('opacity-0', 'pointer-events-none');
      shortcutsModal?.classList.add('opacity-100');
    }
    function closeShortcuts() {
      shortcutsModal?.classList.add('opacity-0', 'pointer-events-none');
      shortcutsModal?.classList.remove('opacity-100');
    }
    document.getElementById('shortcuts-close')?.addEventListener('click', closeShortcuts);
    shortcutsModal?.addEventListener('click', (e) => {
      if (e.target === shortcutsModal) closeShortcuts();
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === '?' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName)) {
        e.preventDefault();
        openShortcuts();
      }
      if (e.key === 'Escape') closeShortcuts();
    });

    // Mobile menu
    const mobileMenu = document.getElementById('mobile-menu');
    document.getElementById('mobile-menu-btn')?.addEventListener('click', () => {
      mobileMenu?.classList.remove('opacity-0', 'pointer-events-none');
      mobileMenu?.classList.add('opacity-100');
    });
    document.getElementById('mobile-menu-close')?.addEventListener('click', closeMobile);
    document.querySelectorAll('.mobile-nav-link').forEach(link => {
      link.addEventListener('click', closeMobile);
    });
    function closeMobile() {
      mobileMenu?.classList.add('opacity-0', 'pointer-events-none');
      mobileMenu?.classList.remove('opacity-100');
    }

    // Notifications
    const notifDrawer = document.getElementById('notif-drawer');
    const notifList = document.getElementById('notif-list');
    function renderNotifs() {
      if (!notifList) return;
      notifList.innerHTML = '';
      // Mark all read header
      const header = document.createElement('div');
      header.className = 'flex justify-end mb-1';
      header.innerHTML = `<button id="notif-mark-read" class="text-xs text-aurora-400 hover:text-aurora-300">Mark all read</button>`;
      notifList.appendChild(header);
      NOTIFICATIONS.forEach(n => {
        const el = document.createElement('div');
        el.className = `p-3 rounded-xl border cursor-pointer transition-colors ${n.unread ? 'bg-aurora-600/10 border-aurora-500/20' : 'bg-void-800/30 border-void-700/40'}`;
        el.innerHTML = `
          <p class="text-sm font-medium text-white">${n.title}</p>
          <p class="text-xs text-void-400 mt-0.5">${n.body}</p>
          <p class="text-[10px] text-void-500 mt-1.5">${n.time}</p>
        `;
        el.addEventListener('click', () => {
          n.unread = false;
          el.className = 'p-3 rounded-xl border cursor-pointer transition-colors bg-void-800/30 border-void-700/40';
          updateNotifDot();
        });
        notifList.appendChild(el);
      });
      document.getElementById('notif-mark-read')?.addEventListener('click', (e) => {
        e.stopPropagation();
        NOTIFICATIONS.forEach(n => { n.unread = false; });
        renderNotifs();
        updateNotifDot();
        toast('All notifications read', 'success');
      });
    }
    function updateNotifDot() {
      const dot = document.querySelector('#notif-btn span');
      if (dot) dot.style.display = NOTIFICATIONS.some(n => n.unread) ? '' : 'none';
    }
    renderNotifs();
    document.getElementById('notif-btn')?.addEventListener('click', () => {
      notifDrawer?.classList.remove('translate-x-full');
    });
    document.getElementById('notif-close')?.addEventListener('click', () => {
      notifDrawer?.classList.add('translate-x-full');
    });
    // Click outside to close notif
    document.addEventListener('click', (e) => {
      if (!notifDrawer || notifDrawer.classList.contains('translate-x-full')) return;
      if (!notifDrawer.contains(e.target) && !document.getElementById('notif-btn')?.contains(e.target)) {
        notifDrawer.classList.add('translate-x-full');
      }
    });

    // Watchlist button
    document.getElementById('watchlist-btn')?.addEventListener('click', () => {
      window.location.href = 'pages/watchlist.html';
    });

    // Profile
    document.getElementById('profile-btn')?.addEventListener('click', () => {
      window.location.href = 'pages/profile.html';
    });

    // Init modules
    initHero();
    initSearch();
    initSwipers();
    initDNABars();
    initUniverse();
    initPlayer();
    initDetail();

    // Section reveal on scroll (GSAP)
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
      if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        gsap.utils.toArray('main > section').forEach((sec, i) => {
          if (i === 0) return; // skip hero
          gsap.from(sec, {
            scrollTrigger: {
              trigger: sec,
              start: 'top 88%',
              toggleActions: 'play none none none',
            },
            opacity: 0,
            y: 36,
            duration: 0.7,
            ease: 'power2.out',
          });
        });
      }
    }

    // View All links
    document.querySelectorAll('a[href="#"]').forEach(a => {
      if (a.textContent.trim() === 'View All') {
        a.addEventListener('click', (e) => {
          e.preventDefault();
          const section = a.closest('section');
          const title = section?.querySelector('h2')?.textContent || 'Catalog';
          toast(`View all: ${title} — open Genres or Search to browse`, 'info');
        });
      }
    });

    // Nav active state on scroll (simple)
    const sections = ['home', 'discover', 'movies', 'series', 'genres', 'releases', 'universe'];
    const navLinks = document.querySelectorAll('[data-nav]');
    window.addEventListener('scroll', () => {
      let current = 'home';
      sections.forEach(id => {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top < 200) current = id;
      });
      navLinks.forEach(link => {
        link.classList.toggle('active', link.dataset.nav === current);
      });
    }, { passive: true });

    // Deep link from hash
    if (window.location.hash) {
      const id = window.location.hash.slice(1);
      if (getById(id)) setTimeout(() => window.openDetail?.(id), 800);
    }

    // Back to top
    const btt = document.getElementById('back-to-top');
    window.addEventListener('scroll', () => {
      if (!btt) return;
      if (window.scrollY > 600) {
        btt.classList.remove('opacity-0', 'pointer-events-none');
        btt.classList.add('opacity-100');
      } else {
        btt.classList.add('opacity-0', 'pointer-events-none');
        btt.classList.remove('opacity-100');
      }
    }, { passive: true });
    btt?.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // Offline / online banner
    const offlineBanner = document.getElementById('offline-banner');
    function setOnline(online) {
      if (!offlineBanner) return;
      if (online) {
        offlineBanner.classList.add('translate-y-full');
      } else {
        offlineBanner.classList.remove('translate-y-full');
        toast('Connection lost', 'error');
      }
    }
    window.addEventListener('online', () => {
      setOnline(true);
      toast('Back online', 'success');
    });
    window.addEventListener('offline', () => setOnline(false));
    if (!navigator.onLine) setOnline(false);

    console.info('%cAnimeVerse', 'font-size:20px;font-weight:bold;color:#6e7cf6', '— Enter the Anime Universe');
    console.info('Demo frontend. Connect authorized APIs & licensed media sources for production.');

    // Magnetic pull on primary hero CTAs (desktop only, respects reduced motion)
    if (window.matchMedia('(pointer:fine)').matches && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      document.querySelectorAll('#watch-now-btn, #explore-btn').forEach((btn) => {
        btn.addEventListener('mousemove', (e) => {
          const r = btn.getBoundingClientRect();
          const x = (e.clientX - r.left - r.width / 2) * 0.22;
          const y = (e.clientY - r.top - r.height / 2) * 0.3;
          btn.style.transform = `translate(${x}px, ${y}px)`;
        });
        btn.addEventListener('mouseleave', () => { btn.style.transform = 'translate(0,0)'; });
      });
    }
  }
})();
