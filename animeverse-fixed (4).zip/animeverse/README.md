# AnimeVerse

**Next-generation cinematic anime entertainment & discovery platform**

Premium frontend demo — not a generic Netflix clone. Fictional catalog only; no unauthorized copyrighted streams.

---

## Quick start

```bash
npx serve .
# or open index.html directly
```

Press `/` for search.

---

## Stack

| Layer | Tech |
|-------|------|
| Markup | HTML5, semantic structure |
| Style | Tailwind CSS, design tokens (void / aurora / cyan) |
| Motion | GSAP + ScrollTrigger, Lenis |
| 3D | Three.js Universe + low-power fallback |
| Carousels | Swiper.js |
| Icons | Inline SVG |
| Persist | localStorage |

---

## Homepage

- Cinematic hero (particles, GSAP entrance, CTAs, sound toggle)
- Nav: transparent → glass; mobile fullscreen menu
- Search overlay (debounced, filters, `/` shortcut)
- Carousels: Continue, Trending, New, Popular, Airing, Movies, Gems, Top-Rated, Classics, Upcoming, Series
- 3D Anime Universe · Anime DNA · Genre grid
- Detail overlay (episodes, DNA, similar, reviews + spoilers)
- Player: seek, speed, quality, subs, Cinema Mode (`T`), fullscreen (`F`), Skip Intro, Next Episode countdown
- Notifications, toasts, loader, PWA manifest

---

## Pages (`pages/`)

| File | Feature |
|------|---------|
| admin.html | Content Studio |
| radar.html | Anime Radar |
| characters.html | Character explorer + graph |
| profile.html | Multi-profile universe |
| watchlist.html | Custom lists |
| timeline.html | Franchise timeline |
| community.html | Reviews & spoilers |
| genres.html | Genre multi-filter |
| recommended.html | Recommendations + signals |
| states.html | Error / empty states |
| about.html | About & content policy |
| accessibility.html | A11y & keyboard map |

---

## Legal

Demo metadata only. Player is a shell for authorized sources. Do not attach pirated streams.

---

© 2026 AnimeVerse demo.

---

## Mobile App Shell (`app.html`)

A touch-first, app-style companion to the desktop site (`index.html`). Open `app.html` on a phone, or install it from the browser menu ("Add to Home Screen") — it ships its own PWA manifest.

### Files

| File | Role |
|------|------|
| `app.html` | Markup only — semantic structure, ARIA, no inline CSS/JS |
| `css/app.css` | App design system: tokens, top bar, hero carousel, cards, footer, tab bar, sheet, search, notifications |
| `js/mobile-app.js` | All behaviour (rendering, sheet, search, notifications, genre filter, watchlist) — no inline handlers |
| `js/tailwind.config.js` | Design tokens (`void`, `aurora`, `ember`, `cyan`) for the Tailwind CDN so catalog gradients like `to-void-950` resolve |
| `app.webmanifest` | PWA manifest (`start_url: app.html`, standalone, portrait) |
| `data/mock.js` | **Shared** with desktop — one catalog, one source of truth |
| `js/utils.js` | **Shared** helpers: `toast`, `debounce`, `storage`, `addToWatchlist` |
| `css/styles.css` | **Shared** grain texture, focus rings, toast styling, reduced-motion |

### What works

- Hero carousel (top-rated titles) with scale-on-swipe and dot indicator
- Genre pills filter every row; empty state with a recovery action
- Rows derived from real catalog data: Continue Watching (real `progress`), Trending, New Releases, Currently Airing, Hidden Gems
- Detail bottom sheet: genres/themes, information grid, episodes; **Watch** shows the licensed-media notice; **+ List** persists to `localStorage` (`av_watchlist`) and reflects state (`✓ In list`)
- Full-screen search (title, alt title, studio, genre) with escaped output, suggestion chips and no-results recovery
- Notification drawer with unread badge and **Mark all read**
- Accessibility: 44px touch targets, dialog roles, focus return, `Escape` to close, hidden overlays removed from tab order, reduced-motion support, 16px search input (no iOS zoom)

### Connecting a real backend

Every data read goes through three functions at the top of `js/mobile-app.js` (`getCatalog`, `getGenres`, `getNotifications`). Replace them with API calls; nothing else in the shell touches the mock data directly. Playback is intentionally not implemented — integrate only **licensed or public-domain** media providers.

### Known scope

Discover, Universe, Saved and Profile tabs open the existing full-site pages (`index.html#…`, `pages/*.html`), which are responsive but not yet restyled in the app-shell design.
